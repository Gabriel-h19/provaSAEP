﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Venda_Carro.Classes
{
    public class ConBanco
    {
        private static string str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Aluno\source\repos\Venda_Carro\Venda_Carro\Database1.mdf;Integrated Security=True;Connect Timeout=30";
        private static SqlConnection con = null;

        public static SqlConnection ObterConexao()
        {
            con = new SqlConnection(str);

            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            try
            {
                con.Open();
            }
            catch (SqlException sqle)
            {
                con = null;

            }

            return con;

        }


        public static void FecharConexao()
        {

            if (con != null || con.State == ConnectionState.Open)
            {
                con.Close();

            }
        }
    }
}
